<?php
//********************************
// Le plus grand des trois
//********************************

// Ecrivez un code qui demande à l'utilisateur de saisir trois nombres
// et lui dire lequel des trois est le plus grand.

// Vous allez (peut-être) devoir imbriquer des conditions les unes dans les autres,
// c'est à dire faire quelque chose comme

// SI (condition) ALORS
//      SI (autre condition) ALORS
//          // code
//      SINON
//          // code
//      FIN SI
// FIN SI