<?php
    $nom = readline ('Comment vous appelez-vous ? ');
    echo 'Bonjour ' . $nom;