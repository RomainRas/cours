<?php

// L'énoncé de cet exercice va être très simple :

// Reprenez le code de l'exercice précédent et modifiez le pour demander 
// à l'utilisateur de taper la chaîne cryptée de départ au lieu de l'écrire en dur dans le code
// utiliser 'readline() que vous avez dû tester le premier jour.


