<?php
for ($i=1; $i<=1000; $i++){
    echo $i . ' ';
}