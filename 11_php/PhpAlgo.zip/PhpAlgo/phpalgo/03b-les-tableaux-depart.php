<?php

// Tableau de geeks
$geeks = [
    '#4eR{z24%à4$Fv9',
    'Hedy Lamar', 
    'FranAllen', 
    'Alexandra Illmer Forsythe', 
    'Tomoe Gozen',
    'Margaret Hamilton',
    'Grace Hopper',
];

// 1 / La première ligne du tableau n'a aucun sens, c'est sûrement un bug, il faut la retirer

// 2 / Il manque "Barbara Liskov" et "Sarita Schoenebeck" à la fin et "Ada Lovelace" au début

// 3 / "FranAllen" est mal orthographié
//   Trouvez le nom mla ortographié et remplacez-le
//   Faites une vraie recherche, n'écrivez pas l'index à la main

// 4 / "Tomoe Gozen" n'était pas une geek, mais une cheffe de guerre samouraï du Japon féodal, 
//    elle n'a rien à faire dans cette liste, il faut la retirer
//    Comme précédemment, cherchez l'index, ne l'écrivez pas à la main

// 5 / Il faut trier le tableau alphabétiquement

// Affiche le tableau final
echo 'Voici une liste de femmes geeks :';

// AFFICHER LA LISTE ICI
