<?php
//********************************
// L'année est-elle bissextile ?
//********************************

// Écrivez un programme qui demande une année à l'utilisateur.
// Dite ensuite à l'utilisateur si cette année est bissextile ou pas.
// Indice : il existe une méthode mathématique pour calculer si une année est bissextile. Cherchez sur internet.
// Indice 2 : Cette méthode consiste en trois tests, si l'année répond aux trois tests, elle est bissextile, sinon, ce n'est pas le cas.
// Si vous ne trouvez qu'un ou deux de ces tests sur les trois, votre programme sera forcément incorrect.

